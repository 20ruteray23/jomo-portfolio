import { useEffect, useState } from 'react';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-off-white/90 backdrop-blur-md shadow-sm'
          : 'bg-transparent'
      }`}
    >
      <div className="flex items-center justify-between px-[6vw] py-4">
        {/* Logo */}
        <button
          onClick={() => scrollToSection('hero')}
          className="font-display font-semibold text-navy text-lg tracking-tight hover:text-gold transition-colors"
        >
          Chilufya Owens
        </button>

        {/* Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          <button
            onClick={() => scrollToSection('about')}
            className="font-sans text-sm text-navy hover:text-gold transition-colors"
          >
            About
          </button>
          <button
            onClick={() => scrollToSection('competencies')}
            className="font-sans text-sm text-navy hover:text-gold transition-colors"
          >
            Skills
          </button>
          <button
            onClick={() => scrollToSection('projects')}
            className="font-sans text-sm text-navy hover:text-gold transition-colors"
          >
            Work
          </button>
          <button
            onClick={() => scrollToSection('contact')}
            className="font-sans text-sm text-navy hover:text-gold transition-colors"
          >
            Contact
          </button>
        </div>
      </div>
    </nav>
  );
}
