import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Download } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const cardHeaderRef = useRef<HTMLDivElement>(null);
  const cardBodyRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const portrait = portraitRef.current;
    const card = cardRef.current;
    const cardHeader = cardHeaderRef.current;
    const cardBody = cardBodyRef.current;

    if (!section || !title || !portrait || !card || !cardHeader || !cardBody) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE phase (0% - 30%)
      scrollTl
        .fromTo(
          title,
          { y: '-10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          portrait,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          card,
          { x: '55vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(
          cardHeader,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.15
        )
        .fromTo(
          cardBody.children,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0.18
        );

      // SETTLE phase (30% - 70%) - elements hold position

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          title,
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          portrait,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          card,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="section-pinned bg-off-white z-20"
    >
      <div className="w-full h-full relative">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="absolute left-[8vw] top-[10vh] font-display font-bold text-navy"
          style={{ fontSize: 'clamp(34px, 3.6vw, 56px)' }}
        >
          About Me
        </h2>

        {/* Portrait */}
        <div
          ref={portraitRef}
          className="absolute left-[8vw] top-[24vh] w-[34vw] h-[58vh] rounded-[10px] overflow-hidden shadow-card"
        >
          <img
            src="/about_portrait.jpg"
            alt="About Chilufya Owens"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content Card */}
        <div
          ref={cardRef}
          className="absolute left-[46vw] top-[22vh] w-[46vw] min-h-[56vh] bg-white rounded-[10px] shadow-card p-8 md:p-10"
        >
          <div ref={cardHeaderRef}>
            <span className="font-mono-label text-slate block mb-2">
              Background
            </span>
            <div className="gold-rule w-16 mb-6" />
          </div>

          <div ref={cardBodyRef} className="space-y-4">
            <p className="text-navy leading-relaxed" style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}>
              I'm a civil engineer by training and a virtual assistant by practice—based 
              in Lusaka, Zambia. My work sits at the intersection of technical standards 
              and human coordination: keeping projects on track, documents in order, and 
              teams aligned.
            </p>

            <p className="text-slate leading-relaxed" style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}>
              I hold a Bachelor's degree in Civil Engineering and am ALX Certified as a 
              Virtual Assistant. This unique combination allows me to bring both technical 
              understanding and administrative excellence to every project I support.
            </p>

            <p className="text-slate leading-relaxed" style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}>
              I've supported site supervision, cost tracking, procurement scheduling, and 
              client communication—always with an eye for clarity and follow-through. Whether 
              it's managing project documentation or coordinating between stakeholders, I 
              deliver results with precision and professionalism.
            </p>

            <button className="link-gold inline-flex items-center gap-2 mt-4">
              <Download size={16} />
              Download full bio
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
