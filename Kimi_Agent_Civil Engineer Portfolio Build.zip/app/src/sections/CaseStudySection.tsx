import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, TrendingDown, Clock, CheckCircle } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const metrics = [
  { icon: Clock, value: '30%', label: 'Reporting time reduced', color: 'text-gold' },
  { icon: TrendingDown, value: '40%', label: 'Authority queries dropped', color: 'text-navy' },
  { icon: CheckCircle, value: '6 days', label: 'Sign-off cycle', color: 'text-gold' },
];

export default function CaseStudySection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const metricsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const portrait = portraitRef.current;
    const card = cardRef.current;
    const metricsContainer = metricsRef.current;

    if (!section || !title || !portrait || !card || !metricsContainer) return;

    const metricItems = metricsContainer.querySelectorAll('.metric-item');

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE phase (0% - 30%)
      scrollTl
        .fromTo(
          title,
          { y: '-10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          portrait,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          card,
          { x: '55vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(
          metricItems,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0.18
        );

      // SETTLE phase (30% - 70%) - elements hold position

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          title,
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          portrait,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          card,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="case-study"
      className="section-pinned bg-off-white z-40"
    >
      <div className="w-full h-full relative">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="absolute left-[8vw] top-[10vh] font-display font-bold text-navy"
          style={{ fontSize: 'clamp(34px, 3.6vw, 56px)' }}
        >
          Case Study
        </h2>

        {/* Portrait */}
        <div
          ref={portraitRef}
          className="absolute left-[8vw] top-[24vh] w-[34vw] h-[58vh] rounded-[10px] overflow-hidden shadow-card"
        >
          <img
            src="/case_study_portrait.jpg"
            alt="Case Study"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content Card */}
        <div
          ref={cardRef}
          className="absolute left-[46vw] top-[22vh] w-[46vw] min-h-[56vh] bg-white rounded-[10px] shadow-card p-8 md:p-10"
        >
          <span className="font-mono-label text-slate block mb-2">
            Project
          </span>
          <div className="gold-rule w-16 mb-4" />
          
          <h3 className="font-display font-semibold text-navy text-xl mb-4">
            Site Compliance & Reporting System
          </h3>

          <div className="space-y-3 mb-6">
            <div>
              <span className="font-mono-label text-gold text-[10px] block mb-1">
                Context
              </span>
              <p className="text-slate text-sm leading-relaxed">
                A residential development needed clearer reporting to meet local 
                authority requirements and streamline project documentation.
              </p>
            </div>

            <div>
              <span className="font-mono-label text-gold text-[10px] block mb-1">
                Actions
              </span>
              <p className="text-slate text-sm leading-relaxed">
                Built a weekly reporting template, standardized photo documentation, 
                and created a tracker for snags and sign-offs.
              </p>
            </div>

            <div>
              <span className="font-mono-label text-gold text-[10px] block mb-1">
                Results
              </span>
              <p className="text-slate text-sm leading-relaxed">
                Improved compliance tracking and reduced documentation overhead 
                through systematic processes and clear communication channels.
              </p>
            </div>
          </div>

          {/* Metrics */}
          <div ref={metricsRef} className="grid grid-cols-3 gap-3 mb-6">
            {metrics.map((metric, index) => (
              <div
                key={index}
                className="metric-item bg-off-white rounded-lg p-3 text-center"
              >
                <metric.icon size={20} className={`mx-auto mb-2 ${metric.color}`} />
                <div className="font-display font-bold text-navy text-lg">
                  {metric.value}
                </div>
                <div className="text-slate text-[10px] leading-tight">
                  {metric.label}
                </div>
              </div>
            ))}
          </div>

          <button className="link-gold inline-flex items-center gap-2">
            Read the full case study
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}
