import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  FileCheck, 
  Users, 
  Calculator, 
  Calendar, 
  ShoppingCart, 
  MessageSquare,
  ArrowRight
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const skills = [
  { icon: FileCheck, label: 'Technical Documentation' },
  { icon: Users, label: 'Project Coordination' },
  { icon: Calculator, label: 'Cost Tracking' },
  { icon: Calendar, label: 'Scheduling' },
  { icon: ShoppingCart, label: 'Procurement Support' },
  { icon: MessageSquare, label: 'Client Communication' },
];

export default function CompetenciesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const skillsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const portrait = portraitRef.current;
    const card = cardRef.current;
    const skillsContainer = skillsRef.current;

    if (!section || !title || !portrait || !card || !skillsContainer) return;

    const skillItems = skillsContainer.querySelectorAll('.skill-item');

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE phase (0% - 30%)
      scrollTl
        .fromTo(
          title,
          { y: '-10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          portrait,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          card,
          { x: '55vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(
          skillItems,
          { y: 16, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.02, ease: 'none' },
          0.15
        );

      // SETTLE phase (30% - 70%) - elements hold position

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          title,
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          portrait,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          card,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="competencies"
      className="section-pinned bg-off-white z-30"
    >
      <div className="w-full h-full relative">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="absolute left-[8vw] top-[10vh] font-display font-bold text-navy"
          style={{ fontSize: 'clamp(34px, 3.6vw, 56px)' }}
        >
          Competencies
        </h2>

        {/* Portrait */}
        <div
          ref={portraitRef}
          className="absolute left-[8vw] top-[24vh] w-[34vw] h-[58vh] rounded-[10px] overflow-hidden shadow-card"
        >
          <img
            src="/competencies_portrait.jpg"
            alt="Chilufya Owens Competencies"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content Card */}
        <div
          ref={cardRef}
          className="absolute left-[46vw] top-[22vh] w-[46vw] min-h-[56vh] bg-white rounded-[10px] shadow-card p-8 md:p-10"
        >
          <span className="font-mono-label text-slate block mb-2">
            Skills
          </span>
          <div className="gold-rule w-16 mb-4" />
          
          <p className="text-slate mb-6" style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}>
            A practical mix of engineering fundamentals and operational execution.
          </p>

          <div ref={skillsRef} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {skills.map((skill, index) => (
              <div
                key={index}
                className="skill-item flex items-center gap-3 p-3 rounded-lg hover:bg-off-white transition-colors cursor-default group"
              >
                <div className="w-10 h-10 rounded-lg bg-off-white flex items-center justify-center group-hover:bg-gold/10 transition-colors">
                  <skill.icon size={20} className="text-navy group-hover:text-gold transition-colors" />
                </div>
                <span className="text-navy font-medium text-sm">{skill.label}</span>
              </div>
            ))}
          </div>

          <button 
            onClick={() => scrollToSection('projects')}
            className="link-gold inline-flex items-center gap-2 mt-6"
          >
            See selected work
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}
