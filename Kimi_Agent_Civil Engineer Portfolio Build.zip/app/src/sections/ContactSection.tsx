import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const contactInfo = [
  { icon: Mail, label: 'Email', value: 'hello@chilufyaowens.com' },
  { icon: Phone, label: 'Phone', value: '+260 XXX XXX XXX' },
  { icon: MapPin, label: 'Location', value: 'Lusaka, Zambia' },
];

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const portrait = portraitRef.current;
    const card = cardRef.current;

    if (!section || !title || !portrait || !card) return;

    const contactItems = card.querySelectorAll('.contact-item');

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE phase (0% - 30%)
      scrollTl
        .fromTo(
          section,
          { opacity: 0 },
          { opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          title,
          { y: '-10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          portrait,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          card,
          { x: '55vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(
          contactItems,
          { y: 16, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0.15
        );

      // SETTLE phase (30% - 70%) - elements hold position

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          title,
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          portrait,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          card,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="section-pinned bg-navy z-[80]"
    >
      <div className="w-full h-full relative">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="absolute left-[8vw] top-[10vh] font-display font-bold text-off-white"
          style={{ fontSize: 'clamp(34px, 3.6vw, 56px)' }}
        >
          Contact
        </h2>

        {/* Portrait */}
        <div
          ref={portraitRef}
          className="absolute left-[8vw] top-[24vh] w-[34vw] h-[58vh] rounded-[10px] overflow-hidden shadow-card"
        >
          <img
            src="/contact_portrait.jpg"
            alt="Contact"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content Card */}
        <div
          ref={cardRef}
          className="absolute left-[46vw] top-[22vh] w-[46vw] min-h-[56vh] rounded-[10px] p-8 md:p-10"
          style={{
            background: 'rgba(244, 246, 248, 0.06)',
            border: '1px solid rgba(244, 246, 248, 0.10)',
          }}
        >
          <span className="font-mono-label text-off-white/60 block mb-2">
            Connect with Me
          </span>
          <div className="gold-rule w-16 mb-4" />
          
          <p className="text-off-white/80 mb-6" style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}>
            Available for engineering support roles, VA engagements, and 
            project-based collaboration.
          </p>

          <div className="space-y-4 mb-8">
            {contactInfo.map((item, index) => (
              <div
                key={index}
                className="contact-item flex items-center gap-4"
              >
                <div className="w-10 h-10 rounded-lg bg-off-white/10 flex items-center justify-center">
                  <item.icon size={18} className="text-gold" />
                </div>
                <div>
                  <span className="font-mono-label text-off-white/40 text-[10px] block">
                    {item.label}
                  </span>
                  <span className="text-off-white text-sm">{item.value}</span>
                </div>
              </div>
            ))}
          </div>

          <button className="btn-primary inline-flex items-center gap-2 bg-gold hover:bg-gold/90 text-navy">
            <Send size={16} />
            Send an email
          </button>
        </div>
      </div>
    </section>
  );
}
