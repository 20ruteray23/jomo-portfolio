import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, Linkedin, Calendar, ArrowUp } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function FooterSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;

    if (!section || !content) return;

    const elements = content.querySelectorAll('.footer-item');

    const ctx = gsap.context(() => {
      gsap.fromTo(
        elements,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          duration: 0.6,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: true,
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <section
      ref={sectionRef}
      id="footer"
      className="bg-off-white py-16 md:py-24 z-[90]"
    >
      <div ref={contentRef} className="max-w-4xl mx-auto px-6 text-center">
        <h2
          className="footer-item font-display font-bold text-navy mb-4"
          style={{ fontSize: 'clamp(34px, 3.6vw, 56px)' }}
        >
          Get in Touch
        </h2>

        <p className="footer-item text-slate mb-8 max-w-md mx-auto">
          I typically respond within 1–2 business days. Let's discuss how I can 
          support your next project.
        </p>

        <div className="footer-item flex items-center justify-center gap-6 mb-12">
          <a
            href="mailto:hello@chilufyaowens.com"
            className="flex items-center gap-2 text-navy hover:text-gold transition-colors"
          >
            <Mail size={18} />
            <span className="text-sm">Email</span>
          </a>
          <a
            href="#"
            className="flex items-center gap-2 text-navy hover:text-gold transition-colors"
          >
            <Linkedin size={18} />
            <span className="text-sm">LinkedIn</span>
          </a>
          <a
            href="#"
            className="flex items-center gap-2 text-navy hover:text-gold transition-colors"
          >
            <Calendar size={18} />
            <span className="text-sm">Schedule a call</span>
          </a>
        </div>

        <div className="footer-item border-t border-navy/10 pt-8 flex items-center justify-between">
          <p className="text-slate text-sm">
            © 2026 Chilufya Owens. All rights reserved.
          </p>
          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-navy hover:text-gold transition-colors text-sm"
          >
            Back to top
            <ArrowUp size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}
