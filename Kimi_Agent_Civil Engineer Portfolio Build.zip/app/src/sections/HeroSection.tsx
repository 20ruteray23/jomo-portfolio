import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { FileText, Mail } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const ruleRef = useRef<HTMLDivElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const bodyRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const portrait = portraitRef.current;
    const title = titleRef.current;
    const rule = ruleRef.current;
    const subtitle = subtitleRef.current;
    const body = bodyRef.current;
    const cta = ctaRef.current;

    if (!section || !portrait || !title || !rule || !subtitle || !body || !cta) return;

    const ctx = gsap.context(() => {
      // Initial state - elements hidden
      gsap.set([portrait, title, rule, subtitle, body, cta], { opacity: 0 });
      gsap.set(portrait, { x: '-12vw' });
      gsap.set(title, { y: 24 });
      gsap.set(rule, { scaleX: 0, transformOrigin: 'left center' });
      gsap.set([subtitle, body, cta], { y: 20 });

      // Auto-play entrance animation on load
      const loadTl = gsap.timeline({ delay: 0.2 });
      
      loadTl
        .to(portrait, { opacity: 1, x: 0, duration: 0.8, ease: 'power3.out' })
        .to(title, { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out' }, '-=0.5')
        .to(rule, { opacity: 1, scaleX: 1, duration: 0.5, ease: 'power2.out' }, '-=0.3')
        .to(subtitle, { opacity: 1, y: 0, duration: 0.5, ease: 'power3.out' }, '-=0.2')
        .to(body, { opacity: 1, y: 0, duration: 0.5, ease: 'power3.out' }, '-=0.3')
        .to(cta, { opacity: 1, y: 0, duration: 0.5, ease: 'power3.out' }, '-=0.3');

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.to([portrait, title, rule, subtitle, body, cta], {
              opacity: 1,
              x: 0,
              y: 0,
              duration: 0.3,
            });
          },
        },
      });

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          portrait,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          [title, subtitle, body],
          { x: 0, opacity: 1 },
          { x: '10vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          rule,
          { scaleX: 1, opacity: 1 },
          { scaleX: 0, opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          cta,
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.75
        );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="section-pinned bg-off-white z-10"
    >
      <div className="w-full h-full flex items-center px-[6vw]">
        {/* Portrait */}
        <div
          ref={portraitRef}
          className="absolute left-[6vw] top-[14vh] w-[38vw] h-[72vh] rounded-[10px] overflow-hidden shadow-card"
        >
          <img
            src="/hero_portrait.jpg"
            alt="Chilufya Owens"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content */}
        <div className="absolute left-[50vw] top-[18vh] w-[44vw]">
          <h1
            ref={titleRef}
            className="font-display font-bold text-navy leading-[1.1]"
            style={{ fontSize: 'clamp(44px, 5vw, 78px)' }}
          >
            Chilufya Owens
          </h1>

          <div
            ref={ruleRef}
            className="gold-rule w-[10vw] mt-6 mb-4"
          />

          <p
            ref={subtitleRef}
            className="font-display font-semibold text-navy text-xl md:text-2xl"
          >
            Civil Engineer & Virtual Assistant
          </p>

          <p
            ref={bodyRef}
            className="text-slate mt-6 max-w-[38vw] leading-relaxed"
            style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}
          >
            I help engineering teams stay organized and deliver—through precise 
            coordination, documentation, and calm execution. With a background in 
            civil engineering and ALX-certified virtual assistance skills, I bridge 
            the gap between technical standards and operational excellence.
          </p>

          <div ref={ctaRef} className="flex items-center gap-4 mt-8">
            <button 
              onClick={() => scrollToSection('resume')}
              className="btn-primary flex items-center gap-2"
            >
              <FileText size={18} />
              View Resume
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="btn-secondary flex items-center gap-2"
            >
              <Mail size={18} />
              Contact Me
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
