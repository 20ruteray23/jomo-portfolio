import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, FileText, Calculator, BarChart3 } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const projects = [
  {
    icon: FileText,
    title: 'Site Diary Automation',
    description: 'Digital system for daily site reporting with automated summaries and photo organization.',
  },
  {
    icon: Calculator,
    title: 'Procurement Tracker',
    description: 'Excel-based tracking system for materials, vendors, and delivery schedules.',
  },
  {
    icon: BarChart3,
    title: 'Client Reporting Kit',
    description: 'Standardized templates for weekly progress reports and milestone updates.',
  },
];

export default function ProjectsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const projectsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const portrait = portraitRef.current;
    const card = cardRef.current;
    const projectsContainer = projectsRef.current;

    if (!section || !title || !portrait || !card || !projectsContainer) return;

    const projectItems = projectsContainer.querySelectorAll('.project-item');

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE phase (0% - 30%)
      scrollTl
        .fromTo(
          title,
          { y: '-10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          portrait,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          card,
          { x: '55vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(
          projectItems,
          { y: 16, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0.15
        );

      // SETTLE phase (30% - 70%) - elements hold position

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          title,
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          portrait,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          card,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="projects"
      className="section-pinned bg-off-white z-[60]"
    >
      <div className="w-full h-full relative">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="absolute left-[8vw] top-[10vh] font-display font-bold text-navy"
          style={{ fontSize: 'clamp(34px, 3.6vw, 56px)' }}
        >
          Projects
        </h2>

        {/* Portrait */}
        <div
          ref={portraitRef}
          className="absolute left-[8vw] top-[24vh] w-[34vw] h-[58vh] rounded-[10px] overflow-hidden shadow-card"
        >
          <img
            src="/projects_portrait.jpg"
            alt="Projects"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content Card */}
        <div
          ref={cardRef}
          className="absolute left-[46vw] top-[22vh] w-[46vw] min-h-[56vh] bg-white rounded-[10px] shadow-card p-8 md:p-10"
        >
          <span className="font-mono-label text-slate block mb-2">
            Selected Work
          </span>
          <div className="gold-rule w-16 mb-4" />
          
          <p className="text-slate mb-6" style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}>
            Small systems and processes that keep projects moving.
          </p>

          <div ref={projectsRef} className="space-y-4 mb-6">
            {projects.map((project, index) => (
              <div
                key={index}
                className="project-item flex gap-4 p-4 bg-off-white rounded-lg hover:bg-navy/5 transition-colors cursor-pointer group"
              >
                <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center flex-shrink-0 group-hover:bg-gold/10 transition-colors">
                  <project.icon size={18} className="text-navy group-hover:text-gold transition-colors" />
                </div>
                <div className="flex-1">
                  <h4 className="font-display font-semibold text-navy text-sm mb-1 group-hover:text-gold transition-colors">
                    {project.title}
                  </h4>
                  <p className="text-slate text-xs leading-relaxed">
                    {project.description}
                  </p>
                </div>
                <ArrowRight 
                  size={16} 
                  className="text-slate flex-shrink-0 self-center opacity-0 group-hover:opacity-100 transform translate-x-[-8px] group-hover:translate-x-0 transition-all" 
                />
              </div>
            ))}
          </div>

          <button className="link-gold inline-flex items-center gap-2">
            Request portfolio
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}
