import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Download, Briefcase, GraduationCap, Award } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const experiences = [
  {
    icon: Briefcase,
    title: 'Civil Engineer (Site Support)',
    organization: 'Various Construction Projects',
    period: '2021 – Present',
    description: 'Site supervision, quality control, and project documentation.',
  },
  {
    icon: Award,
    title: 'Virtual Assistant',
    organization: 'Freelance & Remote',
    period: '2019 – Present',
    description: 'Administrative support, project coordination, and client management.',
  },
  {
    icon: GraduationCap,
    title: 'B.Eng Civil Engineering',
    organization: 'University of Zambia',
    period: '2016 – 2020',
    description: 'Comprehensive engineering education with focus on structural design.',
  },
];

export default function ResumeSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const portrait = portraitRef.current;
    const card = cardRef.current;
    const timeline = timelineRef.current;

    if (!section || !title || !portrait || !card || !timeline) return;

    const timelineItems = timeline.querySelectorAll('.timeline-item');

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE phase (0% - 30%)
      scrollTl
        .fromTo(
          title,
          { y: '-10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          portrait,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          card,
          { x: '55vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(
          timelineItems,
          { x: '6vw', opacity: 0 },
          { x: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0.12
        );

      // SETTLE phase (30% - 70%) - elements hold position

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          title,
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          portrait,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          card,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="resume"
      className="section-pinned bg-off-white z-50"
    >
      <div className="w-full h-full relative">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="absolute left-[8vw] top-[10vh] font-display font-bold text-navy"
          style={{ fontSize: 'clamp(34px, 3.6vw, 56px)' }}
        >
          Resume
        </h2>

        {/* Portrait */}
        <div
          ref={portraitRef}
          className="absolute left-[8vw] top-[24vh] w-[34vw] h-[58vh] rounded-[10px] overflow-hidden shadow-card"
        >
          <img
            src="/resume_portrait.jpg"
            alt="Resume"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content Card */}
        <div
          ref={cardRef}
          className="absolute left-[46vw] top-[22vh] w-[46vw] min-h-[56vh] bg-white rounded-[10px] shadow-card p-8 md:p-10"
        >
          <span className="font-mono-label text-slate block mb-2">
            Experience
          </span>
          <div className="gold-rule w-16 mb-4" />
          
          <p className="text-slate mb-6" style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}>
            A concise track record across engineering support and remote operations.
          </p>

          <div ref={timelineRef} className="space-y-4 mb-6">
            {experiences.map((exp, index) => (
              <div
                key={index}
                className="timeline-item flex gap-4 p-4 bg-off-white rounded-lg"
              >
                <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center flex-shrink-0">
                  <exp.icon size={18} className="text-gold" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <h4 className="font-display font-semibold text-navy text-sm">
                      {exp.title}
                    </h4>
                    <span className="font-mono text-[10px] text-slate">
                      {exp.period}
                    </span>
                  </div>
                  <p className="text-slate text-xs mb-1">{exp.organization}</p>
                  <p className="text-slate text-xs leading-relaxed">
                    {exp.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <button className="btn-primary inline-flex items-center gap-2">
            <Download size={16} />
            Download PDF Resume
          </button>
        </div>
      </div>
    </section>
  );
}
