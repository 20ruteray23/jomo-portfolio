import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Eye, Shield, Repeat, Heart } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const values = [
  {
    icon: Eye,
    title: 'Clarity over noise',
    description: 'Clear communication beats complexity every time.',
  },
  {
    icon: Shield,
    title: 'Ownership without ego',
    description: 'Take responsibility, share credit, stay humble.',
  },
  {
    icon: Repeat,
    title: 'Consistency beats intensity',
    description: 'Reliable progress outperforms sporadic bursts.',
  },
  {
    icon: Heart,
    title: 'Kindness is operational',
    description: 'Respect and empathy drive better outcomes.',
  },
];

export default function ValuesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const portraitRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const valuesRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const portrait = portraitRef.current;
    const card = cardRef.current;
    const valuesContainer = valuesRef.current;

    if (!section || !title || !portrait || !card || !valuesContainer) return;

    const valueItems = valuesContainer.querySelectorAll('.value-item');

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.5,
        },
      });

      // ENTRANCE phase (0% - 30%)
      scrollTl
        .fromTo(
          title,
          { y: '-10vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          portrait,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(
          card,
          { x: '55vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'none' },
          0.05
        )
        .fromTo(
          valueItems,
          { y: 16, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0.15
        );

      // SETTLE phase (30% - 70%) - elements hold position

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(
          title,
          { y: 0, opacity: 1 },
          { y: '-6vh', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          portrait,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(
          card,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="values"
      className="section-pinned bg-off-white z-[70]"
    >
      <div className="w-full h-full relative">
        {/* Section Title */}
        <h2
          ref={titleRef}
          className="absolute left-[8vw] top-[10vh] font-display font-bold text-navy"
          style={{ fontSize: 'clamp(34px, 3.6vw, 56px)' }}
        >
          Values
        </h2>

        {/* Portrait */}
        <div
          ref={portraitRef}
          className="absolute left-[8vw] top-[24vh] w-[34vw] h-[58vh] rounded-[10px] overflow-hidden shadow-card"
        >
          <img
            src="/values_portrait.jpg"
            alt="Values"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content Card */}
        <div
          ref={cardRef}
          className="absolute left-[46vw] top-[22vh] w-[46vw] min-h-[56vh] bg-white rounded-[10px] shadow-card p-8 md:p-10"
        >
          <span className="font-mono-label text-slate block mb-2">
            Principles
          </span>
          <div className="gold-rule w-16 mb-4" />
          
          <p className="text-slate mb-6" style={{ fontSize: 'clamp(15px, 1.2vw, 18px)' }}>
            How I work—and what you can expect.
          </p>

          <div ref={valuesRef} className="space-y-3 mb-6">
            {values.map((value, index) => (
              <div
                key={index}
                className="value-item flex items-start gap-4 p-3 rounded-lg hover:bg-off-white transition-colors"
              >
                <div className="w-8 h-8 rounded-lg bg-off-white flex items-center justify-center flex-shrink-0">
                  <value.icon size={16} className="text-gold" />
                </div>
                <div>
                  <h4 className="font-display font-semibold text-navy text-sm mb-0.5">
                    {value.title}
                  </h4>
                  <p className="text-slate text-xs leading-relaxed">
                    {value.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <button 
            onClick={() => scrollToSection('contact')}
            className="link-gold inline-flex items-center gap-2"
          >
            Let's talk
            <ArrowRight size={16} />
          </button>
        </div>
      </div>
    </section>
  );
}
